﻿using System.IO;
using Utkast1;

class Program
{
    static void Main(string[] args)

    {
        KortleserTabell kl = new KortleserTabell(1234, "Posisjon");     //konstruktør 

        string FilNavn = "KortleserTekstFil";
        StreamReader sr; //= new StreamReader(FilNavn + ".txt");

        sr = File.OpenText(FilNavn + ".txt");
        string kortlesertabellstring = LesFraFilSentral(sr);
        sr.Close();

    }

    public static string LesFraFilSentral(StreamReader sr)
    {
        string line = "";
        // Leser fra tekst filen KortleserTekstFil og sirver ut i CUI. 
        // Vet at dette funker, venter på format fra TCP

        try
        {
            
            line = sr.ReadLine();
            while (line != null)
            {
                Console.WriteLine(line);
                line = sr.ReadLine();
            }
            Console.ReadLine();
        }
        catch (Exception e)
        {
            Console.WriteLine("Exception : " + e.Message);
        }
        finally
        {
            Console.WriteLine("Executing finally block");
        }

        return line;
    }


}


