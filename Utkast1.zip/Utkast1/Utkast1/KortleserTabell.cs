﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utkast1
{
    internal class KortleserTabell
    {
        private int nummer;                                     // Datamedlem, 4 sifre
        private string plassering;                              // Datamedlem, romnummer 3 sifre

        public KortleserTabell(int nummer, string plassering)        // Funksjonsmedlem
        {
            Nummer = nummer;
            Plassering = plassering;
        }

        public int Nummer                                       // Tilgangsmeldem
        {
            get { return nummer; }
            set { nummer = value; }
        }

        public string Plassering                                // Tilgangsmedlem
        {
            get { return plassering; }
            set { plassering = value; }
        }
    }
}
