﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utkast1
{
    internal class Bruker
    {
        Random r = new Random();
        //Datameldemmer                                 //Disse må tilsvare de vi finner i databasen 
        //Ettersom at 
        string etternavn;
        string fornavn;
        string epostAdresse;
        int kortID;
        DateTime gyldighetsperiode;
        string pin;



        // Tilgangsmedlemmer                                               

        public string Etternavn
        {
            get { return etternavn; }
            set
            {
                etternavn = value;
            }
        }

        public string Fornavn
        {
            get { return fornavn; }
            set
            {
                fornavn = value;
            }
        }

        public string EpostAdresse
        {
            get { return epostAdresse; }
            set
            {
                epostAdresse = value;
            }
        }

        public int KortID
        {
            get { return kortID; }
            set
            {
                if (value < 0) kortID = 0;                             //Dette er en situasjon som egentlig ikke vil oppnås
                else kortID = value;
            }
        }

        public DateTime Gyldighetsperiode
        {
            get { return gyldighetsperiode; }
            set
            {
                gyldighetsperiode = value;
            }
        }

        public string PIN                                               //Veger string pga PIN MÅ bestå av 4 siffer
        {                                                               //Har mulighet til å legge til forskjellig antall 0 dersom tallet er under 1000
            get { return pin; }
            set
            {
                pin = value;

            }
        }

        //Konstruktører 
        public Bruker()                                                //DENNE SKAL SLETTES
        {
            Etternavn = "Normann";
            Fornavn = "Ola";
            EpostAdresse = "noelangt@gmail.com";
            KortID = 55;
            Gyldighetsperiode = new DateTime(2015, 12, 25);
            PIN = GenererPinKode();

        }

        public Bruker(string etternavn, string fornavn, string epostadresse, int kortid, DateTime gyldighetsperiode, string pin)
        {
            Etternavn = etternavn;
            Fornavn = fornavn;
            EpostAdresse = epostadresse;
            KortID = kortid;
            Gyldighetsperiode = gyldighetsperiode;
            PIN = pin;
        }



        //Funksjonsmedlemmer 
        public string LeggeTilBruker(Bruker b)
        {
            //Finne ut hvordan hva som er leggetil-kommando er  og hvordan man sender denne til databasen. 
            //Finne ut hvordan en teksstreng mellom C# og databasen vil se ut, hvordan formatere stringen.
            string svar = "";
            //Forslag til formatering
            svar = string.Format("Etternavn{0},Fornavn{1},Epost{2},KortID{3},Gyldighetsperiode{4},PiIN{5}", b.Etternavn, b.Fornavn, b.EpostAdresse, b.KortID, b.Gyldighetsperiode, b.PIN);
            return svar;
            //Her retunerer man en string som skal være en del av stringen man sender til databasen. 
            //Med egen metode 
        }



        public string GenererPinKode()                                //Denne virker 
        {
            string svar = "";
            svar = r.Next(0, 9999).ToString("0000");                  //Sørger for leading zeros, må ha fire siffer
            return svar;
        }

        public string SlettEnbruker(Bruker b)
        {
            string svar = "";
            //Finne ut hvordan hva som er slettekommando og hvordan man sender denne til databasen. 
            return svar;
        }

    }
}
