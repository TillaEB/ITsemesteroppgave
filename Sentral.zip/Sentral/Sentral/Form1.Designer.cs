﻿namespace Sentral
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Alarm1 = new System.Windows.Forms.CheckBox();
            this.Alarm2 = new System.Windows.Forms.CheckBox();
            this.Kortleser = new System.Windows.Forms.CheckedListBox();
            this.Brukerinformasjon = new System.Windows.Forms.ListBox();
            this.Rapport = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Alarm1
            // 
            this.Alarm1.AutoSize = true;
            this.Alarm1.Location = new System.Drawing.Point(45, 394);
            this.Alarm1.Name = "Alarm1";
            this.Alarm1.Size = new System.Drawing.Size(123, 24);
            this.Alarm1.TabIndex = 0;
            this.Alarm1.Text = "Dør brutt opp";
            this.Alarm1.UseVisualStyleBackColor = true;
            // 
            // Alarm2
            // 
            this.Alarm2.AutoSize = true;
            this.Alarm2.Location = new System.Drawing.Point(259, 394);
            this.Alarm2.Name = "Alarm2";
            this.Alarm2.Size = new System.Drawing.Size(157, 24);
            this.Alarm2.TabIndex = 1;
            this.Alarm2.Text = "Dør åpen for lenge";
            this.Alarm2.UseVisualStyleBackColor = true;
            // 
            // Kortleser
            // 
            this.Kortleser.FormattingEnabled = true;
            this.Kortleser.Location = new System.Drawing.Point(45, 55);
            this.Kortleser.Name = "Kortleser";
            this.Kortleser.Size = new System.Drawing.Size(213, 312);
            this.Kortleser.TabIndex = 2;
            // 
            // Brukerinformasjon
            // 
            this.Brukerinformasjon.FormattingEnabled = true;
            this.Brukerinformasjon.ItemHeight = 20;
            this.Brukerinformasjon.Location = new System.Drawing.Point(324, 55);
            this.Brukerinformasjon.Name = "Brukerinformasjon";
            this.Brukerinformasjon.Size = new System.Drawing.Size(196, 304);
            this.Brukerinformasjon.TabIndex = 3;
            // 
            // Rapport
            // 
            this.Rapport.FormattingEnabled = true;
            this.Rapport.ItemHeight = 20;
            this.Rapport.Location = new System.Drawing.Point(561, 55);
            this.Rapport.Name = "Rapport";
            this.Rapport.Size = new System.Drawing.Size(215, 384);
            this.Rapport.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Rapport);
            this.Controls.Add(this.Brukerinformasjon);
            this.Controls.Add(this.Kortleser);
            this.Controls.Add(this.Alarm2);
            this.Controls.Add(this.Alarm1);
            this.Name = "Form1";
            this.Text = "Sentral";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CheckBox Alarm1;
        private CheckBox Alarm2;
        private CheckedListBox Kortleser;
        private ListBox Brukerinformasjon;
        private ListBox Rapport;
    }
}